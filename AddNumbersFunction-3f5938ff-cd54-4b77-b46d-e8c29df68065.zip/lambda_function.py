import json

def lambda_handler(event, context):
    # Retrieve the numbers from the event
    num1 = event.get('num1')
    num2 = event.get('num2')
    
    if num1 is None or num2 is None:
        return {
            'statusCode': 400,
            'body': json.dumps('Missing parameters: num1 or num2')
        }
    
    # Add the two numbers
    result = num1 + num2
    
    return {
        'statusCode': 200,
        'body': json.dumps(f'The result of {num1} + {num2} is {result}')
    }
