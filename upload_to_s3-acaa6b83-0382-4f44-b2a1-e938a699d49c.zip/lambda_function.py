import boto3
import base64
import os

# Initialize the S3 client
s3 = boto3.client('s3')

def lambda_handler(event, context):
    # Define the bucket name from environment variable
    bucket_name = os.environ['BUCKET_NAME']
    
    # Check if the required fields are in the event
    if 'file_name' not in event or 'file_content' not in event:
        return {
            'statusCode': 400,
            'body': 'Missing file_name or file_content in the request.'
        }
    
    file_name = event['file_name']  # Get the file name from the input
    file_content = event['file_content']  # Get the Base64 encoded content
    
    try:
        # Decode the base64 content and ensure proper padding
        padded_file_content = file_content + '=' * (4 - len(file_content) % 4)  # Add padding if needed
        decoded_file = base64.b64decode(padded_file_content)
        
        # Upload the file to the S3 bucket
        s3.put_object(
            Bucket=bucket_name,
            Key=file_name,
            Body=decoded_file
        )
        
        return {
            'statusCode': 200,
            'body': f"File '{file_name}' successfully uploaded to bucket '{bucket_name}'."
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': f"Error uploading file: {str(e)}"
        }
